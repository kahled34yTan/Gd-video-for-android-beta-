GD Video Lab is an experimental foundation for an Android video player in Geometry Dash.

Current status: load-test skeleton only; video playback and object conversion are not implemented.
