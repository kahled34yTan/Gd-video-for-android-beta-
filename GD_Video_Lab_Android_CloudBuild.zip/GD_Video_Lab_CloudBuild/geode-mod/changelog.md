# Changelog

## v0.1.0
- Initial source skeleton.
- No video playback implemented.
