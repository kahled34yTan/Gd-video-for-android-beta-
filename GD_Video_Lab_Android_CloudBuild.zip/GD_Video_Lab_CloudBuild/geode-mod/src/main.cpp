#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

// Milestone 1 only: confirms the mod can load and logs a message.
// This is NOT yet a video player and does not add an in-level video object.
class $modify(GDVideoLabMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }
        log::info("GD Video Lab v0.1 loaded. Video playback is not implemented yet.");
        return true;
    }
};
