# GD Video Lab — Android starter (target configuration)

Target values supplied by the user:
- Geode: `v1.8.0`
- Geometry Dash Android: `2.2.144`

## Current status
This is still a source project, **not an installable `.geode` file**. The C++ code only logs a message when the main menu initializes. It does not yet select videos from Android storage, decode MP4, render video in a level, or convert frames into Geometry Dash objects.

## Build requirements
Build this project with a matching Geode SDK/CLI setup and verify the target game version in that environment. The project has not been compiled or tested on a phone.

Official Geode docs: https://docs.geode-sdk.org/
