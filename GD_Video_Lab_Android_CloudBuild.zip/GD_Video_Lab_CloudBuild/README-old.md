# GD Video Lab v0.1.1 — Android-targeted prototype

This bundle updates the Geode manifest to target Geode `v1.8.0` and Geometry Dash Android `2.2.144`, based on the versions provided by the user.

## Important
- This ZIP is the **source project**, not the `.geode` mod installer.
- The current native mod is only a load-test skeleton. It does not play video yet.
- The website is a local UI prototype; it is not a deployed public website and does not upload/process videos on a server.

Next development milestone: build and test a minimal Android Geode mod, then implement a video picker/player after confirming the available Android media-decoding and rendering path.
# GD Video Lab — Android starter (target configuration)

Target values supplied by the user:
- Geode: `v1.8.0`
- Geometry Dash Android: `2.2.144`

## Current status
This is still a source project, **not an installable `.geode` file**. The C++ code only logs a message when the main menu initializes. It does not yet select videos from Android storage, decode MP4, render video in a level, or convert frames into Geometry Dash objects.

## Build requirements
Build this project with a matching Geode SDK/CLI setup and verify the target game version in that environment. The project has not been compiled or tested on a phone.

Official Geode docs: https://docs.geode-sdk.org/
