# GD Video Lab — Android cloud-build starter

This package adds a GitHub Actions workflow so the small starter mod can be compiled for Android 64-bit without installing the SDK on the phone.

## Important status
- This is a **starter/load-test mod**, not a video player.
- It currently logs a message when the main menu loads. It does not decode MP4, render video in a level, or convert videos to GD objects.
- The workflow uses the Geode SDK version specified in `geode-mod/mod.json` (`v1.8.0`) and targets Android64. Build success and compatibility must be verified in the GitHub Actions log and on the user's device.

## Cloud build from a phone
1. Create a new **public or private** repository on GitHub named `GD-Video-Lab`.
2. Upload the contents of this folder into the repository, keeping folder paths exactly as shown (especially `.github/workflows/build-android.yml` and `geode-mod/`).
3. Ensure the default branch is named `main`.
4. Open the repository's **Actions** tab and select **Build GD Video Lab for Android**.
5. Tap **Run workflow** (or push a commit to `main`) and wait for the run to finish.
6. If it succeeds, open the run and download the artifact named `GD-Video-Lab-Android64`. It should contain a `.geode` file.
7. If it fails, open the run's log and share the first error lines; do not rename the ZIP artifact to `.geode`.

GitHub's interface can differ on mobile. A failed build does not mean the mod works; the source or SDK version may need adjustment.
